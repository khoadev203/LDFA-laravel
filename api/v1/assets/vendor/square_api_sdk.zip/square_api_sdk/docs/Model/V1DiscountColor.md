# V1DiscountColor

### Description


**Note: This model is deprecated.**

## Properties
Name | Type
------------ | -------------
**9da2a6** | string
**4ab200** | string
**0b8000** | string
**2952cc** | string
**a82ee5** | string
**e5457a** | string
**b21212** | string
**593c00** | string
**e5BF00** | string

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

