# CatalogQueryText

### Description



## Properties
Name | Getter | Setter | Type | Description | Notes
------------ | ------------- | ------------- | ------------- | ------------- | -------------
**keywords** | getKeywords() | setKeywords($value) | **string[]** | A list of 1, 2, or 3 search keywords. Keywords with fewer than 3 characters are ignored. | 

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

