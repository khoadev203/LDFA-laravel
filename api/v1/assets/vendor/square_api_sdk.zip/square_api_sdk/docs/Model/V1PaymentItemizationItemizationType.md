# V1PaymentItemizationItemizationType

### Description



## Properties
Name | Type
------------ | -------------
**ITEM** | string
**CUSTOM_AMOUNT** | string
**GIFT_CARD_ACTIVATION** | string
**GIFT_CARD_RELOAD** | string
**GIFT_CARD_UNKNOWN** | string
**OTHER** | string

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

