# CatalogQueryFilteredItemsCustomAttributeFilterFilterType

### Description



## Properties
Name | Type
------------ | -------------
**CUSTOM_ATTRIBUTE_FILTER_TYPE_DO_NOT_USE** | string
**EXACT** | string
**PREFIX** | string
**RANGE** | string

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

